'use strict';

/********************************
 **** Managing all the routes ***
 ********* independently ********
 ********************************/
const Routes = [
    ...require('./v1')
]

module.exports = Routes;