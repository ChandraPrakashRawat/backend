'use strict';

/********************************
 **** Managing all the Hooks ****
 ********* independently ********
 ********************************/

module.exports = {
};