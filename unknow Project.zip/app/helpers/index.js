'use strict';

/********************************
 **** Managing all the helpers ***
 ********* independently ********
 ********************************/
module.exports = {
    ...require('./common/resHelper') 
};