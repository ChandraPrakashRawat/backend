module.exports = {
  portNum: -1,
  listing_limit: 50,
  logLevel: 'error'
};